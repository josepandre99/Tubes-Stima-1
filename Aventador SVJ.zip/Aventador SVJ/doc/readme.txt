				Tugas Besar 1 IF2211 Strategi Algoritma
				      Semester 2 tahun 2018/2019
			  Aplikasi Permainan Kartu 24 dengan Algoritma Greedy

Program Front-End1 
	Tombol 'Draw'  : Untuk mengeluarkan 4 kartu dari tumpukan kartu secara acak.
	Tombol 'Solve' : Untuk menampilkan hasil nilai solusi dari 4 kartu yang terbuka ke layar beserta ekspresinya.
	Tombol 'Exit'  : Untuk keluar dari program.

Program Front-End1 akan memanggil program greedy untuk memberikan hasil nilai solusi beserta ekspresinya.
Program Front-End2 juga akan memanggil program greedy untuk menyelesaikan solusi 4 angka yang diberikan dari file eksternal.


